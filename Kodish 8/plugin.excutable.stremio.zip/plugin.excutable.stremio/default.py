# -*- coding: utf-8 -*- 
import subprocess

subprocess.run("stremio")


