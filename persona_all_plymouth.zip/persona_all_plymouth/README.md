			Persona_Plymouth
	A Simple and Elegant Plymouth that Reflects You

# How to Edit

1. open terminal
2. enter this command
sudo gedit /usr/share/plymouth/themes/persona_bar/persona_bar.script
(to edit Persona_bar Plymouth)

sudo gedit /usr/share/plymouth/themes/persona_bar_text/persona_bar_text.script
(to edit Persona_bar_text Plymouth)

sudo gedit /usr/share/plymouth/themes/persona_circle/persona_circle.script
(to edit Persona_circle Plymouth)


3. (edit Welcome and good bye text) search at script :
# ====================[ Constant here !!!!! ]==================== #

maximum_msg = 5;
ubuntufont = "Ubuntu Light 18";
perfont = "Ubuntu Light 20";
progressfont = "Ubuntu 15";
hi_text = "Hi, M. Syarief Hidayatulloh";
bye_text = "Have a Nice Day, Goodbye";
progress_t= 0;

  * Change "ubuntufont"  with your fav. Font
  * Change "hi_text"  with your fav. word that will show at booting
  * Change "bye_text"  with your fav. word that will show at shutting down or restarting
4. Edit Logo and Background :
  Replace persona.png (to change logo)
  Replace persona_background.png (to change background)

Any Questions?
Plz contact me on
* me.msyariefh@gmail.com
* 085225915434 (Whatsapp)

