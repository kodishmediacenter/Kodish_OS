import xbmcgui
import xbmc
import os




#dialog = xbmcgui.Dialog()
#d = dialog.input('Digite a sua Busca: ', type=xbmcgui.INPUT_ALPHANUM)
os.system("google-chrome-stable --kiosk https://www.primevideo.com/?ref_=dvm_pds_amz_br_dc_s_g|m_4TjCuP62c_c409660716447")


	


