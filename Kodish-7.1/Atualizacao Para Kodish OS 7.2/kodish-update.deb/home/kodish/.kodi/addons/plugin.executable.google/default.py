import xbmcgui
import xbmc
import os




dialog = xbmcgui.Dialog()
d = dialog.input('Digite a sua Busca: ', type=xbmcgui.INPUT_ALPHANUM)
os.system('google-chrome-stable --kiosk https://www.google.com/search?source=hp&ei=roDyXp6uCJ2w5OUP892LgAk&q='+d+'')


	


